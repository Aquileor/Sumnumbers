﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SumNumbers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumNumbers.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void sumTest()
        {
            Assert.Fail();
        }
    }
}